function [A,b]=DD(n)
   T=zeros(n-1,n-1);
   for i=1:n-1
       T(i,i)=2;
   end
   for i=1:n-2
       T(i,i+1)=-1;
       T(i+1,i)=-1;
   end
   I=eye(n-1,n-1);
   k=(n-1)^2;
   A=zeros(k,k);
   b=ones(k,1);
   j=1;
   for i=1:n-1
       A(j:j+n-2,j:j+n-2)=T+2*I;
       j=j+n-1;
   end
   j=1;
   for i=1:n-2
       A(j:j+n-2,j+n-1:j+2*n-3)=-I;
       A(j+n-1:j+2*n-3,j:j+n-2)=-I;
       j=j+n-1;
   end
end
