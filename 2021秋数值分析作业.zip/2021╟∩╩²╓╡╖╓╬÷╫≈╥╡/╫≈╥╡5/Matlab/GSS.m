function []=GSS(n,eps)
   [A,b]=DD(n);
   D=diag(diag(A));L=-tril(A,-1);
   U=-triu(A,1);x=zeros((n-1)^2,1);k=0;maxit=100000;
   B=(D-L)\U;g=(D-L)\b;
   tic
   while 1
       k=k+1;
       x=B*x+g;
       res=b-A*x;
       if norm(res,2)<eps
           break
       elseif k>=maxit
           fprintf('�ﵽ����������\n');
           break
       else
           continue;
       end
   end 
   toc
end