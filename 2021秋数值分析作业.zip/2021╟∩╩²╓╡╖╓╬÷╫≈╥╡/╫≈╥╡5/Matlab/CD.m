function [x,res]=CD(A,b)
AA=A;[~,n]=size(A);
y=zeros(n,1);x=zeros(n,1);
for k=1:1:n
    A(k,k)=sqrt(A(k,k));
    A(1:k-1,k)=0;
    A(k+1:n,k)=A(k+1:n,k)/A(k,k);
    for j=k+1:n
        A(j:n,j)=A(j:n,j)-A(j:n,k)*A(j,k);
    end
end
U=A';L=A;
    y(1,1)=b(1,1)/L(1,1);
for i=2:n
    s=0;
    for j=1:i-1
        s=s+y(j,1)*L(i,j);
    end
    y(i,1)=(b(i,1)-s)/L(i,i);
end
x(n,1)=y(n,1)/U(n,n);
for i=n-1:-1:1
    s=0;
    for j=i+1:n
        s=s+U(i,j)*x(j,1);
    end
    x(i,1)=(y(i,1)-s)/U(i,i);
end
res=norm(b-AA*x);